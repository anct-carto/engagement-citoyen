## Certificat de garantie d’origine du développeur
 
En contribuant à ce projet :
 
(a) je certifie être le seul développeur de ma contribution et/ou avoir le droit, sans restriction ni réserve, de soumettre ma contribution au Système de Design de l’Etat ; 
 
(b) je certifie que ma contribution ne s’appuie pas sur des travaux antérieurs qui pourraient en restreindre l’usage dans le cadre du Système de Design de l’Etat ; 
 
(c) je garantis la jouissance paisible de ma contribution, dans le cadre du Système de Design de l’Etat ; 
 
(d) Je reconnais et j'accepte que ma contribution fasse l’objet d’un usage public dans le cadre du Système de Design de l’Etat et que les droits d’exploitation y afférents soient selon le contexte (i) cédés à l’État ou (ii) soumis aux dispositions de la licence open source en vigueur pour les Composants de la Plateforme du Système de Design de l’État. 
 

Signature : 
