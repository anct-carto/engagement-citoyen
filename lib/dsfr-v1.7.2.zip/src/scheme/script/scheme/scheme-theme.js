export const SchemeTheme = {
  LIGHT: 'light',
  DARK: 'dark'
};
