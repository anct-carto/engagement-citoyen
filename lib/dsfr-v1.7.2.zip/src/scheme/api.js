import api from '../core/api.js';
export default api;
