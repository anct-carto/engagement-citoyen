import api from './index.js';

api.internals.register(api.scheme.SchemeSelector.SCHEME, api.scheme.Scheme);

export default api;
