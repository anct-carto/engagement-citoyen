// TODO : Supprimer ce fichier après modification du build pour ne pas charger le pck Legacy dans le script dsfr.module.js
import './script/index';
