import ns from '../namespace.js';

export const TransitionSelector = {
  NONE: ns.selector('transition-none')
};
