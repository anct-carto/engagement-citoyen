import { TransitionSelector } from './transition-selector';

const selector = {};

selector.TransitionSelector = TransitionSelector;

export default selector;
