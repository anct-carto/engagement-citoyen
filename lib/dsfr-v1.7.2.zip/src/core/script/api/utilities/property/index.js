import { completeAssign } from './complete-assign';

const property = {};

property.completeAssign = completeAssign;

export default property;
