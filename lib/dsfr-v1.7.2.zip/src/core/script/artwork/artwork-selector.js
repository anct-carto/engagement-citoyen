import ns from '../api/utilities/namespace.js';

export const ArtworkSelector = {
  ARTWORK_USE: `${ns.selector('artwork')} use`
};
