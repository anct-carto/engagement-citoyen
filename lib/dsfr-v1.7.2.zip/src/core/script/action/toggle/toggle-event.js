import ns from '../../api/utilities/namespace.js';

const ToggleEvent = {
  TOGGLE: ns.event('toggle')
};

export { ToggleEvent };
