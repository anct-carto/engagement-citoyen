import ns from '../api/utilities/namespace.js';

export const EquisizedEmission = {
  CHANGE: ns('equisized', 'change')
};
