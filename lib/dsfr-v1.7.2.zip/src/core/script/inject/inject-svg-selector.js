import ns from '../api/utilities/namespace.js';

export const InjectSvgSelector = {
  INJECT_SVG: `[${ns.attr('inject-svg')}]`
};
