import config from './config.js';
const api = window[config.namespace];
export default api;
