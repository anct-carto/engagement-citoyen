import api from '../legacy.js';
export default api;
